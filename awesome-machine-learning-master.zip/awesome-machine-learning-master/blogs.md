Blogs/Podcasts
===============

[Hacker News for Data Science](http://www.datatau.com/news)

Podcasts
--------

[The O'Reilly Data Show](http://radar.oreilly.com/tag/oreilly-data-show-podcast)

[Partially Derivative](http://www.partiallyderivative.com/)

[The Talking Machines](http://www.thetalkingmachines.com/)

[The Data Skeptic](http://dataskeptic.com/)

[Linear Digressions](https://www.udacity.com/podcasts/linear-digressions)

[Data Stories](http://datastori.es/)

[Learning Machines 101](http://www.learningmachines101.com/)

[Not So Standard Deviations](http://simplystatistics.org/2015/09/17/not-so-standard-deviations-the-podcast/)

Data Science / Statistics
-------------------------

http://iamtrask.github.io/

http://blog.explainmydata.com/

http://andrewgelman.com/

http://simplystatistics.org/

http://www.evanmiller.org/

http://jakevdp.github.io/

http://blog.yhathq.com/

http://blog.wesmckinney.com/

http://www.overkillanalytics.net/

http://newton.cx/~peter/

http://mbakker7.github.io/exploratory_computing_with_python/

http://sebastianraschka.com/articles.html

http://camdavidsonpilon.github.io/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers/

http://colah.github.io/

http://snippyhollow.github.io/

http://www.thomasdimson.com/

http://blog.smellthedata.com/

http://sebastianraschka.com/

http://dogdogfish.com/

http://www.johnmyleswhite.com/

http://drewconway.com/zia/

http://bugra.github.io/

http://opendata.cern.ch/

http://alexanderetz.com/

http://www.sumsar.net/

http://countbayesie.com

http://karpathy.github.io/

http://blog.dato.com/

http://blog.kaggle.com/

http://www.danvk.org/

http://hunch.net/

http://www.randalolson.com/blog/

http://www.johndcook.com/blog/r_language_for_programmers/

Math
----

http://www.sumsar.net/

http://allendowney.blogspot.ca/

http://healthyalgorithms.com/

http://petewarden.com/

http://mrtz.org/blog/


Security Related
----------------

http://jordan-wright.github.io/blog/
